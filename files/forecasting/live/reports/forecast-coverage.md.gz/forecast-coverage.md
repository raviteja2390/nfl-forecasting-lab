# Forecast issuance coverage

Checked 2026-11-23T00:08:30.529826Z.

15 games have missed model issuance. Collection success does not resolve these gaps.

Pre-launch games are excluded. No retrospective forecast may fill a prospective gap.

- 2026_05_BAL_ATL: missing outcome-logit-v1, player-form-v1, player-availability-v1; deadline 2026-10-11T00:20:00+00:00
- 2026_05_CHI_GB: missing outcome-logit-v1, player-form-v1, player-availability-v1; deadline 2026-10-10T17:00:00+00:00
- 2026_05_CIN_MIA: missing outcome-logit-v1, player-form-v1, player-availability-v1; deadline 2026-10-10T17:00:00+00:00
- 2026_05_CLE_NYJ: missing outcome-logit-v1, player-form-v1, player-availability-v1; deadline 2026-10-10T17:00:00+00:00
- 2026_05_DEN_LAC: missing outcome-logit-v1, player-form-v1, player-availability-v1; deadline 2026-10-10T20:05:00+00:00
- 2026_05_DET_ARI: missing outcome-logit-v1, player-form-v1, player-availability-v1; deadline 2026-10-10T20:25:00+00:00
- 2026_05_HOU_TEN: missing outcome-logit-v1, player-form-v1, player-availability-v1; deadline 2026-10-10T17:00:00+00:00
- 2026_05_IND_PIT: missing outcome-logit-v1, player-form-v1, player-availability-v1; deadline 2026-10-10T17:00:00+00:00
- 2026_05_LV_NE: missing outcome-logit-v1, player-form-v1, player-availability-v1; deadline 2026-10-10T17:00:00+00:00
- 2026_05_MIN_NO: missing outcome-logit-v1, player-form-v1, player-availability-v1; deadline 2026-10-10T17:00:00+00:00
- 2026_05_NYG_WAS: missing outcome-logit-v1, player-form-v1, player-availability-v1; deadline 2026-10-10T17:00:00+00:00
- 2026_05_PHI_JAX: missing outcome-logit-v1, player-form-v1, player-availability-v1; deadline 2026-10-10T13:30:00+00:00
- 2026_05_SF_SEA: missing outcome-logit-v1, player-form-v1, player-availability-v1; deadline 2026-10-10T20:25:00+00:00
- 2026_11_JAX_NYG: missing outcome-logit-v1, player-form-v1, player-availability-v1; deadline 2026-11-21T21:25:00+00:00
- 2026_11_PIT_PHI: missing outcome-logit-v1, player-form-v1, player-availability-v1; deadline 2026-11-21T18:00:00+00:00
