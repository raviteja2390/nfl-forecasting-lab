# Prospective promotion status

Interim comparisons are descriptive; no profitability conclusion. Formal decisions use the fixed review cutoff.

Fixed review: 2027-02-08T12:00:00Z.

- player-form-v1: awaiting-fixed-review; 34 paired scored games across 4 weeks.
- player-availability-v1: awaiting-fixed-review; 34 paired scored games across 4 weeks.
