# Prospective forecast tracking

As of 2026-11-01T05:07:53.763844Z. Only forecasts saved before kickoff and independently confirmed final results are scored.

- **outcome-logit-v1:** 62 scored, 13 pending; accuracy 53.2%, log loss 0.670215.
- **player-availability-v1:** 62 scored, 13 pending; accuracy 61.3%, log loss 0.669515.
- **player-form-v1:** 62 scored, 13 pending; accuracy 56.5%, log loss 0.680651.
- **Paired comparison — player-availability-v1:** 62 shared games, log-loss improvement versus team-only 0.000700.
- **Paired comparison — player-form-v1:** 62 shared games, log-loss improvement versus team-only -0.010436.

Positive paired loss improvement favors the player challenger. These descriptive results need a substantial prospective sample; no automatic model promotion or profitability claim is made.
